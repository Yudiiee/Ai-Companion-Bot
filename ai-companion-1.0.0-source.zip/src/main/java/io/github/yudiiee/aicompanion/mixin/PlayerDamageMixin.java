package io.github.yudiiee.aicompanion.mixin;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import io.github.yudiiee.aicompanion.PlayerUtils.PlayerRetaliationTracker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Mixin to detect when bot player entities are damaged by other players
 * This enables the player retaliation system
 */
@Mixin(ServerPlayer.class)
public class PlayerDamageMixin {

    @Inject(method = "hurtServer", at = @At("HEAD"))
    private void onPlayerDamaged(ServerLevel level, DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        ServerPlayer bot = (ServerPlayer) (Object) this;

        // Check if damage source is another player
        Entity attacker = source.getEntity();
        if (attacker instanceof Player playerAttacker) {
            // Don't track damage from the bot to itself
            if (playerAttacker.getUUID().equals(bot.getUUID())) {
                return;
            }

            // Record the hit for retaliation tracking
            PlayerRetaliationTracker.recordPlayerHit(bot, playerAttacker);
        }
    }
}
